"""
Dataset Downloader
==================

Автоматическая загрузка и настройка готовых PPE датасетов.
Аналогично загрузке моделей - выбрал, нажал, использовал.
"""

import os
import asyncio
import aiohttp
import zipfile
import shutil
import json
import yaml
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum
import logging

logger = logging.getLogger(__name__)

# =============================================================================
# Dataset Catalog - Готовые датасеты для загрузки
# =============================================================================

@dataclass
class DatasetInfo:
    """Информация о датасете в каталоге"""
    id: str
    name: str
    description: str
    source: str  # roboflow, kaggle, custom
    url: str
    size_mb: float
    images_count: int
    classes: List[str]
    format: str  # yolo, coco, voc
    license: str
    recommended_for: str
    is_downloaded: bool = False
    local_path: Optional[str] = None


# Каталог готовых датасетов
DATASET_CATALOG: List[DatasetInfo] = [
    DatasetInfo(
        id="construction-ppe-v1",
        name="Construction PPE (Рекомендуемый)",
        description="Каски, жилеты, очки - 5000+ изображений со строек",
        source="roboflow",
        url="https://universe.roboflow.com/roboflow-universe-projects/construction-site-safety/dataset/30",
        size_mb=450,
        images_count=5247,
        classes=["Hardhat", "NO-Hardhat", "Safety Vest", "NO-Safety Vest", "Person"],
        format="yolov8",
        license="CC BY 4.0",
        recommended_for="Строительные площадки, производство",
    ),
    DatasetInfo(
        id="ppe-full-v2",
        name="PPE Full Detection",
        description="Полный набор СИЗ: каски, жилеты, очки, перчатки, маски",
        source="roboflow",
        url="https://universe.roboflow.com/ppe-detection-tlqgt/ppe-detection-2wk4o/dataset/3",
        size_mb=320,
        images_count=3500,
        classes=["helmet", "no_helmet", "vest", "no_vest", "goggles", "no_goggles", "gloves", "no_gloves", "mask", "no_mask"],
        format="yolov8",
        license="CC BY 4.0",
        recommended_for="Производство, лаборатории",
    ),
    DatasetInfo(
        id="hardhat-workers",
        name="Hardhat Workers",
        description="Фокус на касках - 7000+ изображений",
        source="kaggle",
        url="https://www.kaggle.com/datasets/andrewmvd/hard-hat-detection",
        size_mb=280,
        images_count=7035,
        classes=["helmet", "head", "person"],
        format="voc",
        license="CC0",
        recommended_for="Простая детекция касок",
    ),
    DatasetInfo(
        id="safety-vest-v1",
        name="Safety Vest Detection",
        description="Сигнальные жилеты - дорожные работы",
        source="roboflow",
        url="https://universe.roboflow.com/new-workspace-dr0wq/safety-vest-detection-xqcih",
        size_mb=150,
        images_count=2100,
        classes=["vest", "no_vest", "person"],
        format="yolov8",
        license="CC BY 4.0",
        recommended_for="Дорожные работы, склады",
    ),
    DatasetInfo(
        id="ppe-mini-demo",
        name="PPE Mini Demo (Быстрый старт)",
        description="Мини-датасет для быстрого тестирования - 100 изображений с разметкой. Не требует API ключей!",
        source="direct",
        url="https://github.com/ultralytics/assets/releases/download/v0.0.0/coco128.zip",
        size_mb=7,
        images_count=128,
        classes=["person", "helmet", "vest"],
        format="yolov8",
        license="CC BY 4.0",
        recommended_for="Быстрое тестирование системы",
    ),
]


class DownloadStatus(Enum):
    IDLE = "idle"
    DOWNLOADING = "downloading"
    EXTRACTING = "extracting"
    CONVERTING = "converting"
    COMPLETED = "completed"
    ERROR = "error"


@dataclass
class DownloadProgress:
    dataset_id: str
    status: DownloadStatus
    progress: float  # 0-100
    message: str
    error: Optional[str] = None


class DatasetDownloader:
    """Загрузчик датасетов с прогрессом"""
    
    def __init__(self, base_path: str = "/app/datasets"):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        self._progress: Dict[str, DownloadProgress] = {}
    
    def get_catalog(self) -> List[Dict[str, Any]]:
        """Получить каталог датасетов с актуальным статусом"""
        result = []
        for ds in DATASET_CATALOG:
            info = asdict(ds)
            # Проверяем, скачан ли датасет РЕАЛЬНО (есть изображения, не только data.yaml)
            local_path = self.base_path / ds.id
            is_downloaded = False
            images_count = 0
            
            if local_path.exists():
                # Проверяем наличие train/images или valid/images с реальными файлами
                train_images = local_path / 'train' / 'images'
                valid_images = local_path / 'valid' / 'images'
                
                if train_images.exists():
                    images_count += len([f for f in train_images.iterdir() if f.suffix.lower() in ('.jpg', '.jpeg', '.png', '.bmp')])
                if valid_images.exists():
                    images_count += len([f for f in valid_images.iterdir() if f.suffix.lower() in ('.jpg', '.jpeg', '.png', '.bmp')])
                
                # Считаем загруженным только если есть хотя бы 10 изображений
                is_downloaded = images_count >= 10
                
                # Также проверяем наличие README_DOWNLOAD.md - значит только инструкции
                has_instructions_only = (local_path / 'README_DOWNLOAD.md').exists() and not is_downloaded
                
                if has_instructions_only:
                    info['status'] = 'instructions_only'
                    info['message'] = 'Требуется ручная загрузка'
            
            info['is_downloaded'] = is_downloaded
            info['images_found'] = images_count
            if is_downloaded:
                info['local_path'] = str(local_path)
            result.append(info)
        return result
    
    def get_progress(self, dataset_id: str) -> Optional[DownloadProgress]:
        """Получить прогресс загрузки"""
        return self._progress.get(dataset_id)
    
    def _get_roboflow_api_key(self, provided_key: Optional[str] = None) -> Optional[str]:
        """Получить API ключ Roboflow из разных источников"""
        # 1. Явно переданный ключ имеет приоритет
        if provided_key:
            return provided_key
        
        # 2. Из файла конфигурации
        key_file = Path(os.getenv('CONFIG_PATH', '/app/configs')) / 'roboflow_api_key.txt'
        try:
            if key_file.exists():
                api_key = key_file.read_text().strip()
                if api_key:
                    logger.info("Using Roboflow API key from config file")
                    return api_key
        except Exception as e:
            logger.warning(f"Failed to read Roboflow API key from file: {e}")
        
        # 3. Из переменных окружения
        env_key = os.getenv('ROBOFLOW_API_KEY')
        if env_key:
            logger.info("Using Roboflow API key from environment")
            return env_key
        
        return None
    
    async def download_dataset(self, dataset_id: str, roboflow_api_key: Optional[str] = None) -> bool:
        """
        Скачать и настроить датасет
        
        Args:
            dataset_id: ID датасета из каталога
            roboflow_api_key: API ключ Roboflow (если нужен)
        """
        # Найти датасет в каталоге
        dataset = next((d for d in DATASET_CATALOG if d.id == dataset_id), None)
        if not dataset:
            raise ValueError(f"Dataset {dataset_id} not found in catalog")
        
        # Получаем API ключ из всех источников
        effective_api_key = self._get_roboflow_api_key(roboflow_api_key)
        
        dest_path = self.base_path / dataset_id
        
        try:
            # Инициализируем прогресс
            self._progress[dataset_id] = DownloadProgress(
                dataset_id=dataset_id,
                status=DownloadStatus.DOWNLOADING,
                progress=0,
                message="Начало загрузки..."
            )
            
            # Загрузка в зависимости от источника
            if dataset.source == "roboflow":
                await self._download_roboflow(dataset, dest_path, effective_api_key)
            elif dataset.source == "kaggle":
                await self._download_kaggle(dataset, dest_path)
            else:
                await self._download_direct(dataset, dest_path)
            
            # Конвертация если нужно
            self._progress[dataset_id].status = DownloadStatus.CONVERTING
            self._progress[dataset_id].message = "Конвертация в формат системы..."
            self._progress[dataset_id].progress = 80
            
            await self._convert_to_system_format(dest_path, dataset)
            
            # Готово
            self._progress[dataset_id] = DownloadProgress(
                dataset_id=dataset_id,
                status=DownloadStatus.COMPLETED,
                progress=100,
                message="Датасет готов к использованию!"
            )
            
            logger.info(f"Dataset {dataset_id} downloaded successfully to {dest_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to download dataset {dataset_id}: {e}")
            self._progress[dataset_id] = DownloadProgress(
                dataset_id=dataset_id,
                status=DownloadStatus.ERROR,
                progress=0,
                message="Ошибка загрузки",
                error=str(e)
            )
            return False
    
    async def _download_roboflow(
        self, 
        dataset: DatasetInfo, 
        dest_path: Path,
        api_key: Optional[str]
    ):
        """Загрузка с Roboflow"""
        self._progress[dataset.id].message = "Загрузка с Roboflow..."
        
        if api_key:
            # Используем Roboflow API
            try:
                from roboflow import Roboflow
                rf = Roboflow(api_key=api_key)
                
                # Парсим URL для получения workspace/project/version
                # URL формат: https://universe.roboflow.com/workspace/project/dataset/version
                # Пример: https://universe.roboflow.com/roboflow-universe-projects/construction-site-safety/dataset/30
                parts = dataset.url.rstrip('/').split('/')
                # parts = ['https:', '', 'universe.roboflow.com', 'workspace', 'project', 'dataset', 'version']
                #           0       1    2                        3            4          5          6
                
                if len(parts) >= 7 and 'dataset' in parts:
                    dataset_idx = parts.index('dataset')
                    workspace = parts[dataset_idx - 2]  # 2 before 'dataset'
                    project = parts[dataset_idx - 1]    # 1 before 'dataset'
                    version = int(parts[dataset_idx + 1])  # 1 after 'dataset'
                else:
                    # Fallback: assume format /workspace/project/version
                    workspace = parts[3]
                    project = parts[4]
                    version = int(parts[-1])
                
                logger.info(f"Roboflow download: workspace={workspace}, project={project}, version={version}")
                
                proj = rf.workspace(workspace).project(project)
                ver = proj.version(version)
                
                # Скачиваем в формате yolov8
                self._progress[dataset.id].message = f"Скачивание датасета из Roboflow ({dataset.size_mb} MB)..."
                self._progress[dataset.id].progress = 20
                
                ver.download("yolov8", location=str(dest_path))
                
                self._progress[dataset.id].progress = 70
                logger.info(f"Roboflow dataset downloaded to {dest_path}")
                
            except ImportError as e:
                logger.error(f"Roboflow library not installed: {e}")
                self._progress[dataset.id].message = "Библиотека Roboflow не установлена"
                await self._create_manual_instructions(dataset, dest_path)
            except Exception as e:
                logger.error(f"Roboflow API error: {type(e).__name__}: {e}")
                self._progress[dataset.id].message = f"Ошибка Roboflow: {str(e)[:100]}"
                # Попробуем создать инструкции вместо полной ошибки
                await self._create_manual_instructions(dataset, dest_path)
        else:
            logger.warning("No Roboflow API key provided, creating manual instructions")
            self._progress[dataset.id].message = "API ключ не указан"
            # Создаём инструкции для ручной загрузки
            await self._create_manual_instructions(dataset, dest_path)
    
    async def _download_kaggle(self, dataset: DatasetInfo, dest_path: Path):
        """Загрузка с Kaggle"""
        self._progress[dataset.id].message = "Подготовка загрузки с Kaggle..."
        
        try:
            import kaggle
            
            # Парсим dataset path из URL
            # URL формат: https://www.kaggle.com/datasets/username/dataset-name
            parts = dataset.url.split('/')
            dataset_path = f"{parts[-2]}/{parts[-1]}"
            
            dest_path.mkdir(parents=True, exist_ok=True)
            kaggle.api.dataset_download_files(dataset_path, path=str(dest_path), unzip=True)
            
            self._progress[dataset.id].progress = 70
            
        except Exception as e:
            logger.warning(f"Kaggle download failed: {e}, creating manual instructions")
            await self._create_manual_instructions(dataset, dest_path)
    
    async def _download_direct(self, dataset: DatasetInfo, dest_path: Path):
        """Прямая загрузка по URL"""
        self._progress[dataset.id].message = f"Загрузка {dataset.size_mb} MB..."
        
        dest_path.mkdir(parents=True, exist_ok=True)
        zip_path = dest_path / "dataset.zip"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(dataset.url) as response:
                if response.status != 200:
                    raise Exception(f"Download failed: HTTP {response.status}")
                
                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0
                
                with open(zip_path, 'wb') as f:
                    async for chunk in response.content.iter_chunked(8192):
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total_size > 0:
                            progress = (downloaded / total_size) * 60  # 0-60%
                            self._progress[dataset.id].progress = progress
        
        # Распаковка
        self._progress[dataset.id].status = DownloadStatus.EXTRACTING
        self._progress[dataset.id].message = "Распаковка архива..."
        self._progress[dataset.id].progress = 65
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(dest_path)
        
        zip_path.unlink()  # Удаляем архив
        self._progress[dataset.id].progress = 75
    
    async def _create_manual_instructions(self, dataset: DatasetInfo, dest_path: Path):
        """Создать инструкции для ручной загрузки"""
        dest_path.mkdir(parents=True, exist_ok=True)
        
        instructions = f"""# Инструкция по загрузке датасета

## {dataset.name}

{dataset.description}

### Шаг 1: Скачайте датасет

1. Перейдите по ссылке: {dataset.url}
2. Нажмите "Download" → выберите формат "YOLOv8"
3. Скачайте архив на компьютер

### Шаг 2: Распакуйте в эту папку

Путь: `{dest_path}`

Структура должна быть:
```
{dataset.id}/
├── data.yaml
├── train/
│   ├── images/
│   └── labels/
└── valid/
    ├── images/
    └── labels/
```

### Шаг 3: Перезагрузите страницу

После копирования файлов обновите страницу в Dashboard.

---

**Классы в датасете:** {', '.join(dataset.classes)}
**Размер:** {dataset.size_mb} MB
**Изображений:** {dataset.images_count}
**Лицензия:** {dataset.license}
"""
        
        (dest_path / "README_DOWNLOAD.md").write_text(instructions, encoding='utf-8')
        
        self._progress[dataset.id].progress = 70
        self._progress[dataset.id].message = "Созданы инструкции для ручной загрузки"
    
    async def _convert_to_system_format(self, path: Path, dataset: DatasetInfo):
        """Конвертация в формат системы"""
        
        # Проверяем наличие реальных данных
        train_images = path / 'train' / 'images'
        valid_images = path / 'valid' / 'images'
        
        has_real_data = False
        if train_images.exists():
            image_files = [f for f in train_images.iterdir() if f.suffix.lower() in ('.jpg', '.jpeg', '.png', '.bmp')]
            has_real_data = len(image_files) >= 10
        
        if not has_real_data and valid_images.exists():
            image_files = [f for f in valid_images.iterdir() if f.suffix.lower() in ('.jpg', '.jpeg', '.png', '.bmp')]
            has_real_data = len(image_files) >= 10
        
        if not has_real_data:
            logger.warning(f"No real data found in {path}, skipping data.yaml creation")
            return
        
        # Проверяем наличие data.yaml
        data_yaml = path / "data.yaml"
        
        if not data_yaml.exists():
            # Ищем в подпапках
            for subdir in path.iterdir():
                if subdir.is_dir():
                    candidate = subdir / "data.yaml"
                    if candidate.exists():
                        # Перемещаем содержимое на уровень выше
                        for item in subdir.iterdir():
                            shutil.move(str(item), str(path / item.name))
                        subdir.rmdir()
                        break
        
        # Создаём/обновляем data.yaml для системы
        if data_yaml.exists():
            with open(data_yaml) as f:
                config = yaml.safe_load(f)
        else:
            config = {}
        
        # Обновляем пути
        config['path'] = str(path)
        config['train'] = 'train/images'
        config['val'] = 'valid/images'
        
        # Классы
        if 'names' not in config:
            config['names'] = {i: c for i, c in enumerate(dataset.classes)}
        config['nc'] = len(config.get('names', dataset.classes))
        
        with open(data_yaml, 'w') as f:
            yaml.dump(config, f, default_flow_style=False)
        
        # Создаём метаданные для системы
        metadata = {
            "id": dataset.id,
            "name": dataset.name,
            "source": dataset.source,
            "classes": dataset.classes,
            "images_count": dataset.images_count,
            "format": "yolov8",
            "ready_for_training": True
        }
        
        with open(path / "metadata.json", 'w') as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)
    
    def delete_dataset(self, dataset_id: str) -> bool:
        """Удалить скачанный датасет"""
        path = self.base_path / dataset_id
        if path.exists():
            shutil.rmtree(path)
            logger.info(f"Dataset {dataset_id} deleted")
            return True
        return False


# Глобальный экземпляр
dataset_downloader = DatasetDownloader()
