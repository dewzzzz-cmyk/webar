/**
 * Dataset Catalog Component
 * =========================
 * 
 * Каталог готовых PPE датасетов для быстрой загрузки.
 * UX аналогичен каталогу моделей - выбрал, скачал, использовал.
 */

import { useState, useEffect } from 'react';
import {
  Download,
  Database,
  Loader2,
  Check,
  AlertCircle,
  ExternalLink,
  Trash2,
  RefreshCw,
  Package,
  Image as ImageIcon,
  Tag,
  Shield,
  Eye,
  EyeOff,
  Key,
  X,
  Edit2,
  Save,
  FolderOpen,
  CheckCircle,
} from 'lucide-react';

interface DatasetCatalogItem {
  id: string;
  name: string;
  description: string;
  source: string;
  url: string;
  size_mb: number;
  images_count: number;
  classes: string[];
  format: string;
  license: string;
  recommended_for: string;
  is_downloaded: boolean;
  local_path?: string;
  status?: string;  // 'instructions_only' when only manual instructions exist
  message?: string;
  images_found?: number;
}

interface DownloadProgress {
  dataset_id: string;
  status: 'idle' | 'downloading' | 'extracting' | 'converting' | 'completed' | 'error';
  progress: number;
  message: string;
  error?: string;
}

interface DatasetCatalogProps {
  onDatasetReady?: (datasetId: string) => void;
}

export function DatasetCatalog({ onDatasetReady }: DatasetCatalogProps) {
  const [catalog, setCatalog] = useState<DatasetCatalogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState<Record<string, DownloadProgress>>({});
  const [apiKey, setApiKey] = useState('');
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [showApiKey, setShowApiKey] = useState(false);
  const [isEditingApiKey, setIsEditingApiKey] = useState(false);
  const [apiKeySaving, setApiKeySaving] = useState(false);
  const [showApiKeyInput, setShowApiKeyInput] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Загрузка API key из localStorage и сервера
  useEffect(() => {
    loadApiKey();
  }, []);

  const loadApiKey = async () => {
    // Сначала пробуем загрузить с сервера
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/settings/roboflow-api-key', {
        headers: token ? { 'Authorization': `Bearer ${token}` } : {},
      });
      if (response.ok) {
        const data = await response.json();
        if (data.api_key) {
          setApiKey(data.api_key);
          setApiKeyInput(data.api_key);
          localStorage.setItem('roboflow_api_key', data.api_key);
          return;
        }
      }
    } catch (e) {
      console.warn('Failed to load API key from server:', e);
    }
    
    // Fallback на localStorage
    const savedApiKey = localStorage.getItem('roboflow_api_key');
    if (savedApiKey) {
      setApiKey(savedApiKey);
      setApiKeyInput(savedApiKey);
    }
  };

  // Сохранение API key
  const saveApiKey = async () => {
    const keyToSave = apiKeyInput.trim();
    if (!keyToSave) return;
    
    setApiKeySaving(true);
    try {
      // Сохраняем на сервер
      const token = localStorage.getItem('token');
      const response = await fetch('/api/settings/roboflow-api-key', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ api_key: keyToSave }),
      });
      
      if (response.ok) {
        setApiKey(keyToSave);
        localStorage.setItem('roboflow_api_key', keyToSave);
        setIsEditingApiKey(false);
        setError(null);
      } else {
        // Fallback - сохраняем только в localStorage
        setApiKey(keyToSave);
        localStorage.setItem('roboflow_api_key', keyToSave);
        setIsEditingApiKey(false);
      }
    } catch (e) {
      // Fallback - сохраняем только в localStorage
      setApiKey(keyToSave);
      localStorage.setItem('roboflow_api_key', keyToSave);
      setIsEditingApiKey(false);
    } finally {
      setApiKeySaving(false);
    }
  };

  // Удаление API key
  const clearApiKey = async () => {
    if (!confirm('Удалить API ключ Roboflow?')) return;
    
    try {
      const token = localStorage.getItem('token');
      await fetch('/api/settings/roboflow-api-key', {
        method: 'DELETE',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {},
      });
    } catch (e) {
      console.warn('Failed to delete API key from server:', e);
    }
    
    setApiKey('');
    setApiKeyInput('');
    localStorage.removeItem('roboflow_api_key');
    setIsEditingApiKey(false);
  };

  // Начать редактирование
  const startEditing = () => {
    setApiKeyInput(apiKey);
    setIsEditingApiKey(true);
    setShowApiKey(true);
  };

  // Отмена редактирования
  const cancelEditing = () => {
    setApiKeyInput(apiKey);
    setIsEditingApiKey(false);
    setShowApiKey(false);
  };

  // Загрузка каталога
  useEffect(() => {
    fetchCatalog();
  }, []);

  const fetchCatalog = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/training/catalog/datasets');
      if (response.ok) {
        const data = await response.json();
        setCatalog(data);
      } else {
        throw new Error('Failed to fetch catalog');
      }
    } catch (err) {
      setError('Не удалось загрузить каталог датасетов');
      // Используем fallback данные
      setCatalog([
        {
          id: "construction-ppe-v1",
          name: "Construction PPE (Рекомендуемый)",
          description: "Каски, жилеты - 5000+ изображений со строек",
          source: "roboflow",
          url: "https://universe.roboflow.com/roboflow-universe-projects/construction-site-safety/dataset/30",
          size_mb: 450,
          images_count: 5247,
          classes: ["Hardhat", "NO-Hardhat", "Safety Vest", "NO-Safety Vest", "Person"],
          format: "yolov8",
          license: "CC BY 4.0",
          recommended_for: "Строительные площадки",
          is_downloaded: false
        }
        // Demo Mini удалён - содержал неподходящие изображения (коты, машины, ванные)
      ]);
    } finally {
      setLoading(false);
    }
  };

  const startDownload = async (datasetId: string, needsApiKey: boolean = false) => {
    // Если нужен API ключ и его нет - показать поле ввода
    if (needsApiKey && !apiKey) {
      setError('Введите API ключ Roboflow выше для загрузки датасета');
      return;
    }

    try {
      setError(null);
      setDownloading(prev => ({
        ...prev,
        [datasetId]: {
          dataset_id: datasetId,
          status: 'downloading',
          progress: 0,
          message: 'Начало загрузки...'
        }
      }));

      const url = `/api/training/catalog/datasets/${datasetId}/download${apiKey ? `?roboflow_api_key=${encodeURIComponent(apiKey)}` : ''}`;
      const response = await fetch(url, { method: 'POST' });

      if (!response.ok) {
        throw new Error('Download failed');
      }

      // Polling для прогресса
      const pollProgress = setInterval(async () => {
        try {
          const statusResponse = await fetch(`/api/training/catalog/datasets/${datasetId}/status`);
          if (statusResponse.ok) {
            const progress: DownloadProgress = await statusResponse.json();
            setDownloading(prev => ({ ...prev, [datasetId]: progress }));

            if (progress.status === 'completed') {
              clearInterval(pollProgress);
              fetchCatalog(); // Обновляем каталог
              onDatasetReady?.(datasetId);
            } else if (progress.status === 'error') {
              clearInterval(pollProgress);
            }
          }
        } catch (err) {
          clearInterval(pollProgress);
        }
      }, 1000);

      // Остановить polling через 10 минут максимум
      setTimeout(() => clearInterval(pollProgress), 600000);

    } catch (err) {
      setDownloading(prev => ({
        ...prev,
        [datasetId]: {
          dataset_id: datasetId,
          status: 'error',
          progress: 0,
          message: 'Ошибка загрузки',
          error: err instanceof Error ? err.message : 'Unknown error'
        }
      }));
    }
  };

  const importDataset = async (datasetId: string) => {
    try {
      setDownloading(prev => ({
        ...prev,
        [datasetId]: {
          dataset_id: datasetId,
          status: 'converting',
          progress: 50,
          message: 'Импорт изображений в систему...'
        }
      }));

      const response = await fetch(`/api/training/catalog/datasets/${datasetId}/import`, {
        method: 'POST'
      });

      if (!response.ok) {
        throw new Error('Import failed');
      }

      const result = await response.json();

      setDownloading(prev => ({
        ...prev,
        [datasetId]: {
          dataset_id: datasetId,
          status: 'completed',
          progress: 100,
          message: `Импортировано ${result.imported} изображений`
        }
      }));

      // Обновляем каталог
      setTimeout(() => {
        fetchCatalog();
        onDatasetReady?.(datasetId);
        setDownloading(prev => {
          const next = { ...prev };
          delete next[datasetId];
          return next;
        });
      }, 2000);

    } catch (err) {
      setDownloading(prev => ({
        ...prev,
        [datasetId]: {
          dataset_id: datasetId,
          status: 'error',
          progress: 0,
          message: 'Ошибка импорта',
          error: err instanceof Error ? err.message : 'Unknown error'
        }
      }));
    }
  };

  const deleteDataset = async (datasetId: string) => {
    if (!confirm('Удалить датасет? Все данные будут удалены.')) return;

    try {
      const response = await fetch(`/api/training/catalog/datasets/${datasetId}`, {
        method: 'DELETE'
      });
      if (response.ok) {
        fetchCatalog();
      }
    } catch (err) {
      setError('Не удалось удалить датасет');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 animate-spin text-primary-600" />
        <span className="ml-2">Загрузка каталога...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Database className="w-5 h-5 text-primary-600" />
            Каталог PPE Датасетов
          </h3>
          <p className="text-sm text-gray-500 mt-1">
            Выберите датасет и нажмите "Загрузить" — система настроит всё автоматически
          </p>
        </div>
        <button
          onClick={fetchCatalog}
          className="btn-secondary text-sm flex items-center gap-1"
        >
          <RefreshCw className="w-4 h-4" />
          Обновить
        </button>
      </div>

      {error && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 flex items-center gap-2 text-yellow-700 text-sm">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}

      {/* Roboflow API Key - Enhanced UI */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Key className="w-5 h-5 text-blue-600 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-medium text-blue-800">
              API ключ Roboflow (для загрузки датасетов)
            </p>
            <p className="text-xs text-blue-600 mt-1">
              Бесплатная регистрация на <a href="https://app.roboflow.com" target="_blank" rel="noopener noreferrer" className="underline hover:text-blue-800">app.roboflow.com</a> → Settings → API Keys
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            {!apiKey && !isEditingApiKey ? (
              /* Нет ключа - показываем поле ввода */
              <>
                <input
                  type={showApiKey ? 'text' : 'password'}
                  value={apiKeyInput}
                  onChange={(e) => setApiKeyInput(e.target.value)}
                  placeholder="Вставьте API ключ"
                  className="input text-sm w-64"
                  onKeyDown={(e) => e.key === 'Enter' && saveApiKey()}
                />
                <button
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="p-2 text-gray-500 hover:text-gray-700"
                  title={showApiKey ? 'Скрыть' : 'Показать'}
                >
                  {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
                <button
                  onClick={saveApiKey}
                  disabled={!apiKeyInput.trim() || apiKeySaving}
                  className="btn-primary text-sm flex items-center gap-1"
                >
                  {apiKeySaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  Сохранить
                </button>
              </>
            ) : isEditingApiKey ? (
              /* Режим редактирования */
              <>
                <input
                  type={showApiKey ? 'text' : 'password'}
                  value={apiKeyInput}
                  onChange={(e) => setApiKeyInput(e.target.value)}
                  placeholder="Вставьте новый API ключ"
                  className="input text-sm w-64"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') saveApiKey();
                    if (e.key === 'Escape') cancelEditing();
                  }}
                />
                <button
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="p-2 text-gray-500 hover:text-gray-700"
                  title={showApiKey ? 'Скрыть' : 'Показать'}
                >
                  {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
                <button
                  onClick={saveApiKey}
                  disabled={!apiKeyInput.trim() || apiKeySaving}
                  className="btn-primary text-sm flex items-center gap-1"
                >
                  {apiKeySaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  Сохранить
                </button>
                <button
                  onClick={cancelEditing}
                  className="p-2 text-gray-500 hover:text-gray-700"
                  title="Отмена"
                >
                  <X className="w-4 h-4" />
                </button>
              </>
            ) : (
              /* Ключ сохранён - показываем статус и кнопки */
              <>
                <div className="flex items-center gap-2 bg-green-100 text-green-700 px-3 py-1.5 rounded-lg text-sm">
                  <Check className="w-4 h-4" />
                  <span className="font-medium">Сохранён</span>
                  <span className="text-green-600 font-mono">
                    {apiKey.slice(0, 8)}...{apiKey.slice(-4)}
                  </span>
                </div>
                <button
                  onClick={startEditing}
                  className="p-2 text-gray-500 hover:text-blue-600 transition-colors"
                  title="Изменить ключ"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={clearApiKey}
                  className="p-2 text-gray-500 hover:text-red-600 transition-colors"
                  title="Удалить ключ"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Dataset Cards */}
      <div className="grid gap-4">
        {catalog.map((dataset) => {
          const progress = downloading[dataset.id];
          const isDownloading = progress && !['completed', 'error', 'idle'].includes(progress.status);

          return (
            <div
              key={dataset.id}
              className={`
                border rounded-lg p-4 transition-all
                ${dataset.is_downloaded ? 'border-green-200 bg-green-50/30' : 'border-gray-200 hover:border-primary-200'}
              `}
            >
              <div className="flex items-start justify-between">
                {/* Info */}
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold">{dataset.name}</h4>
                    {dataset.is_downloaded && (
                      <span className="px-2 py-0.5 rounded-full text-xs bg-green-100 text-green-700 flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        Загружен ({dataset.images_found?.toLocaleString() || '?'} изобр.)
                      </span>
                    )}
                    {dataset.status === 'instructions_only' && (
                      <span className="px-2 py-0.5 rounded-full text-xs bg-yellow-100 text-yellow-700 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        Требуется ручная загрузка
                      </span>
                    )}
                    {dataset.id === 'construction-ppe-v1' && !dataset.is_downloaded && dataset.status !== 'instructions_only' && (
                      <span className="px-2 py-0.5 rounded-full text-xs bg-primary-100 text-primary-700">
                        Рекомендуем
                      </span>
                    )}
                  </div>
                  
                  <p className="text-sm text-gray-600 mt-1">{dataset.description}</p>
                  
                  {/* Manual download message */}
                  {dataset.status === 'instructions_only' && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded p-2 mt-2 text-xs text-yellow-700">
                      <p className="font-medium">Автоматическая загрузка не удалась</p>
                      <p>Проверьте API ключ Roboflow или <a href={dataset.url} target="_blank" rel="noopener noreferrer" className="underline">скачайте вручную</a></p>
                    </div>
                  )}
                  
                  {/* Stats */}
                  <div className="flex flex-wrap gap-4 mt-3 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <ImageIcon className="w-4 h-4" />
                      {dataset.images_count.toLocaleString()} изображений
                    </span>
                    <span className="flex items-center gap-1">
                      <Tag className="w-4 h-4" />
                      {dataset.classes.length} классов
                    </span>
                    <span className="flex items-center gap-1">
                      <Package className="w-4 h-4" />
                      {dataset.size_mb} MB
                    </span>
                    <span className="flex items-center gap-1">
                      <Shield className="w-4 h-4" />
                      {dataset.license}
                    </span>
                  </div>

                  {/* Classes */}
                  <div className="flex flex-wrap gap-1 mt-2">
                    {dataset.classes.slice(0, 5).map((cls, i) => (
                      <span
                        key={i}
                        className={`px-2 py-0.5 rounded text-xs ${
                          cls.includes('NO-') || cls.includes('no_')
                            ? 'bg-red-100 text-red-700'
                            : 'bg-gray-100 text-gray-700'
                        }`}
                      >
                        {cls}
                      </span>
                    ))}
                    {dataset.classes.length > 5 && (
                      <span className="px-2 py-0.5 rounded text-xs bg-gray-100 text-gray-500">
                        +{dataset.classes.length - 5}
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col items-end gap-2 ml-4">
                  {(!dataset.is_downloaded || dataset.status === 'instructions_only') && !isDownloading && (
                    <>
                      <button
                        onClick={() => startDownload(dataset.id, dataset.source === 'roboflow')}
                        className="btn-primary text-sm flex items-center gap-2"
                      >
                        <Download className="w-4 h-4" />
                        Загрузить
                      </button>
                      {/* Кнопка импорта если папка существует */}
                      {(dataset.images_found ?? 0) > 0 && (
                        <button
                          onClick={() => importDataset(dataset.id)}
                          className="btn-secondary text-sm flex items-center gap-2"
                        >
                          <FolderOpen className="w-4 h-4" />
                          Импорт ({dataset.images_found} фото)
                        </button>
                      )}
                      <a
                        href={dataset.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-gray-500 hover:text-primary-600 flex items-center gap-1"
                      >
                        <ExternalLink className="w-3 h-3" />
                        Источник
                      </a>
                    </>
                  )}

                  {isDownloading && (
                    <div className="text-right">
                      <div className="flex items-center gap-2 text-sm text-blue-600">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        {progress.message}
                      </div>
                      <div className="w-32 h-2 bg-gray-200 rounded-full mt-2 overflow-hidden">
                        <div
                          className="h-full bg-blue-500 transition-all duration-300"
                          style={{ width: `${progress.progress}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-500">{progress.progress.toFixed(0)}%</span>
                    </div>
                  )}

                  {dataset.is_downloaded && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-green-600 flex items-center gap-1">
                        <CheckCircle className="w-4 h-4" />
                        Готов ({dataset.images_found ?? 0} изобр.)
                      </span>
                      <button
                        onClick={() => importDataset(dataset.id)}
                        className="p-1 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded"
                        title="Импортировать в систему"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteDataset(dataset.id)}
                        className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded"
                        title="Удалить"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {progress?.status === 'error' && (
                    <div className="text-right">
                      <span className="text-sm text-red-600">{progress.error}</span>
                      <button
                        onClick={() => startDownload(dataset.id)}
                        className="btn-secondary text-xs mt-1"
                      >
                        Повторить
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* API Key Input Modal */}
              {showApiKeyInput === dataset.id && (
                <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-800 mb-2">
                    Для загрузки с Roboflow нужен API ключ (бесплатно):
                  </p>
                  <ol className="text-xs text-blue-700 list-decimal list-inside mb-3 space-y-1">
                    <li>Зарегистрируйтесь на <a href="https://app.roboflow.com" target="_blank" className="underline">app.roboflow.com</a></li>
                    <li>Перейдите в Settings → API Keys</li>
                    <li>Скопируйте Private API Key</li>
                  </ol>
                  <div className="flex gap-2">
                    <input
                      type="password"
                      value={apiKeyInput}
                      onChange={(e) => setApiKeyInput(e.target.value)}
                      placeholder="Вставьте API ключ"
                      className="input flex-1 text-sm"
                    />
                    <button
                      onClick={() => {
                        if (apiKeyInput.trim()) {
                          saveApiKey();
                        }
                        setShowApiKeyInput(null);
                        startDownload(dataset.id, false);
                      }}
                      disabled={!apiKeyInput.trim()}
                      className="btn-primary text-sm"
                    >
                      Загрузить
                    </button>
                    <button
                      onClick={() => setShowApiKeyInput(null)}
                      className="btn-secondary text-sm"
                    >
                      Отмена
                    </button>
                  </div>
                  <p className="text-xs text-blue-600 mt-2">
                    Без API ключа будут созданы инструкции для ручной загрузки
                  </p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Help */}
      <div className="bg-gray-50 rounded-lg p-4 text-sm">
        <h4 className="font-medium mb-2">💡 Как это работает:</h4>
        <ol className="list-decimal list-inside space-y-1 text-gray-600">
          <li>Выберите датасет из каталога</li>
          <li>Нажмите "Загрузить" — система скачает и настроит всё автоматически</li>
          <li>Перейдите в "Обучение" → датасет уже готов к использованию</li>
        </ol>
      </div>
    </div>
  );
}

export default DatasetCatalog;
