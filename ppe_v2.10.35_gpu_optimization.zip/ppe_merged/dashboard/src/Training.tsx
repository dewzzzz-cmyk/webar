import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Upload,
  Image as ImageIcon,
  Play,
  Square,
  Trash2,
  Check,
  Loader2,
  Download,
  FolderOpen,
  Tag,
  Cpu,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Layers,
  ZoomIn,
  ZoomOut,
  MousePointer,
  Plus,
  X,
  StopCircle,
} from 'lucide-react';
import { Layout } from '@/components/layout/Layout';
import { useWebSocket } from '@/hooks/useWebSocket';
import { trainingApi } from '@/api/training';
import { useTrainingProgress } from '@/hooks/useTrainingProgress';
import type { TrainingImage } from '@/types/training';
import { PPE_CLASSES, CLASS_COLORS } from '@/types/training';
import { ModelSelector, SplitSelector, AdvancedOptions, type ModelType } from '@/components/training/ModelSelector';

// Re-export CLASSES for local use
const CLASSES = PPE_CLASSES;

export function TrainingPage() {
  const [activeTab, setActiveTab] = useState<'upload' | 'annotate' | 'train' | 'models'>('upload');
  const [selectedImages, setSelectedImages] = useState<Set<string>>(new Set());
  const [currentImage, setCurrentImage] = useState<TrainingImage | null>(null);
  const [selectedClass, setSelectedClass] = useState<string>('no_hardhat');
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawStart, setDrawStart] = useState<{ x: number; y: number } | null>(null);
  const [tempBox, setTempBox] = useState<[number, number, number, number] | null>(null);
  const [zoom, setZoom] = useState(1);
  const [tool, setTool] = useState<'select' | 'draw'>('draw');
  
  // Dataset state
  const [currentDatasetId, setCurrentDatasetId] = useState<string | null>(null);
  const [showDatasetModal, setShowDatasetModal] = useState(false);
  const [newDatasetName, setNewDatasetName] = useState('');
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const { isConnected } = useWebSocket();
  
  // Состояние для размеров изображения
  const [imageDimensions, setImageDimensions] = useState<{ width: number; height: number } | null>(null);
  const [imageLoadError, setImageLoadError] = useState<string | null>(null);

  // ============================================================================
  // API Queries - Real data from backend
  // ============================================================================
  
  // Fetch datasets
  const { data: datasets = [], isLoading: datasetsLoading } = useQuery({
    queryKey: ['training-datasets'],
    queryFn: () => trainingApi.datasets.list(),
  });

  // Auto-select first dataset if none selected
  useEffect(() => {
    if (!currentDatasetId && datasets.length > 0) {
      setCurrentDatasetId(datasets[0].id);
    }
  }, [datasets, currentDatasetId]);

  // Fetch images for current dataset with pagination
  const { data: imagesData, isLoading: imagesLoading } = useQuery({
    queryKey: ['training-images', currentDatasetId, currentPage, pageSize],
    queryFn: async () => {
      if (!currentDatasetId) return { items: [], total: 0, page: 1, page_size: pageSize };
      return trainingApi.images.list(currentDatasetId, { page: currentPage, pageSize: pageSize });
    },
    enabled: !!currentDatasetId,
  });
  
  const images = imagesData?.items ?? [];
  const totalImages = imagesData?.total ?? 0;
  const totalPages = Math.ceil(totalImages / pageSize);
  
  // Reset page when dataset changes
  useEffect(() => {
    setCurrentPage(1);
  }, [currentDatasetId]);

  // Fetch current training job (running or most recent)
  const { data: trainingJobs = [] } = useQuery({
    queryKey: ['training-jobs'],
    queryFn: () => trainingApi.jobs.list(undefined, 5),
    refetchInterval: 5000, // Poll every 5 seconds
  });
  
  const trainingJob = trainingJobs.find(j => j.status === 'running') || trainingJobs[0] || null;

  // Use WebSocket for real-time training progress - triggers UI updates
  const { progress: wsProgress } = useTrainingProgress(
    trainingJob?.status === 'running' ? trainingJob.id : null
  );

  // When websocket gives progress, invalidate queries for fresh data
  useEffect(() => {
    if (wsProgress) {
      queryClient.invalidateQueries({ queryKey: ['training-jobs'] });
    }
  }, [wsProgress, queryClient]);

  // Sync canvas size with image
  useEffect(() => {
    if (imageRef.current && canvasRef.current && imageDimensions) {
      canvasRef.current.width = imageDimensions.width;
      canvasRef.current.height = imageDimensions.height;
    }
  }, [imageDimensions, currentImage]);

  // Reset image state when changing image
  useEffect(() => {
    setImageDimensions(null);
    setImageLoadError(null);
  }, [currentImage?.id]);

  // Handle image load
  const handleImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    const img = e.currentTarget;
    setImageDimensions({ width: img.naturalWidth, height: img.naturalHeight });
    setImageLoadError(null);
  };

  // Handle image error
  const handleImageError = () => {
    setImageLoadError('Не удалось загрузить изображение');
    setImageDimensions(null);
  };

  // Fetch models
  const { data: models = [], isLoading: modelsLoading } = useQuery({
    queryKey: ['training-models'],
    queryFn: () => trainingApi.models.list(),
  });

  // ============================================================================
  // Mutations - Real API calls
  // ============================================================================

  // Create dataset mutation
  const createDatasetMutation = useMutation({
    mutationFn: (data: { name: string; description?: string }) => 
      trainingApi.datasets.create(data),
    onSuccess: (newDataset) => {
      queryClient.invalidateQueries({ queryKey: ['training-datasets'] });
      setCurrentDatasetId(newDataset.id);
      setShowDatasetModal(false);
      setNewDatasetName('');
    },
    onError: (error: Error) => {
      console.error('Failed to create dataset:', error);
      alert(`Не удалось создать датасет: ${error.message}`);
    },
  });

  // Upload mutation
  const uploadMutation = useMutation({
    mutationFn: async (files: FileList) => {
      if (!currentDatasetId) {
        throw new Error('Выберите или создайте датасет');
      }
      return trainingApi.images.upload(currentDatasetId, files);
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['training-images', currentDatasetId] });
      queryClient.invalidateQueries({ queryKey: ['training-datasets'] });
      if (result.total_errors > 0) {
        console.warn('Some files failed to upload:', result.errors);
      }
    },
  });

  // Delete images mutation
  const deleteImagesMutation = useMutation({
    mutationFn: async (imageIds: string[]) => {
      return trainingApi.images.deleteBatch(imageIds);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-images', currentDatasetId] });
      queryClient.invalidateQueries({ queryKey: ['training-datasets'] });
      setSelectedImages(new Set());
    },
  });

  // Add annotation mutation
  const addAnnotationMutation = useMutation({
    mutationFn: async ({ imageId, annotation }: { 
      imageId: string; 
      annotation: { class_name: string; bbox_x1: number; bbox_y1: number; bbox_x2: number; bbox_y2: number } 
    }) => {
      return trainingApi.annotations.create(imageId, annotation);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-images', currentDatasetId] });
    },
  });

  // Delete annotation mutation
  const deleteAnnotationMutation = useMutation({
    mutationFn: (annotationId: string) => trainingApi.annotations.delete(annotationId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-images', currentDatasetId] });
    },
  });

  // Auto-annotate mutation
  const autoAnnotateMutation = useMutation({
    mutationFn: async (imageId: string) => {
      const response = await fetch(`/api/training/images/${imageId}/auto-annotate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({ detail: 'Auto-annotate failed' }));
        throw new Error(error.detail);
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-images', currentDatasetId] });
    },
  });

  // Auto-annotate all images mutation
  const autoAnnotateAllMutation = useMutation({
    mutationFn: async () => {
      if (!currentDatasetId) throw new Error('No dataset selected');
      const response = await fetch(`/api/training/datasets/${currentDatasetId}/auto-annotate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({ detail: 'Auto-annotate failed' }));
        throw new Error(error.detail);
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-images', currentDatasetId] });
    },
  });

  // Start training mutation
  const startTrainingMutation = useMutation({
    mutationFn: async (params: { 
      // Model selection
      model_type: string;
      model_size: string;
      // Data split
      train_split: number;
      val_split: number;
      test_split: number;
      // Training params
      epochs: number; 
      batch_size: number; 
      learning_rate: number;
      image_size?: number;
      augmentation?: boolean;
      pretrained?: boolean;
      // Advanced
      optimizer?: string;
      patience?: number;
    }) => {
      if (!currentDatasetId) {
        throw new Error('Выберите датасет');
      }
      return trainingApi.jobs.create({
        dataset_id: currentDatasetId,
        ...params,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-jobs'] });
    },
  });

  // Cancel training mutation
  const cancelTrainingMutation = useMutation({
    mutationFn: (jobId: string) => trainingApi.jobs.cancel(jobId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-jobs'] });
    },
  });

  // Activate model mutation
  const activateModelMutation = useMutation({
    mutationFn: (modelId: string) => trainingApi.models.activate(modelId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-models'] });
    },
  });

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      uploadMutation.mutate(e.target.files);
    }
  };

  // Handle drag and drop
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      uploadMutation.mutate(e.dataTransfer.files);
    }
  }, [uploadMutation]);

  // Drawing handlers
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (tool !== 'draw' || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    
    setIsDrawing(true);
    setDrawStart({ x, y });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !drawStart || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    
    setTempBox([
      Math.min(drawStart.x, x),
      Math.min(drawStart.y, y),
      Math.max(drawStart.x, x),
      Math.max(drawStart.y, y),
    ]);
  };

  const handleMouseUp = () => {
    if (isDrawing && tempBox && currentImage) {
      // Validate box size (at least 10px in each dimension)
      const boxWidth = tempBox[2] - tempBox[0];
      const boxHeight = tempBox[3] - tempBox[1];
      
      if (boxWidth > 0.01 && boxHeight > 0.01) {
        // Add annotation via API
        addAnnotationMutation.mutate({
          imageId: currentImage.id,
          annotation: {
            class_name: selectedClass,
            bbox_x1: tempBox[0],
            bbox_y1: tempBox[1],
            bbox_x2: tempBox[2],
            bbox_y2: tempBox[3],
          },
        });
      }
    }
    
    setIsDrawing(false);
    setDrawStart(null);
    setTempBox(null);
  };

  // Delete annotation handler
  const handleDeleteAnnotation = (annotationId: string) => {
    deleteAnnotationMutation.mutate(annotationId);
  };

  // Training parameters
  const [trainingParams, setTrainingParams] = useState({
    // Model selection
    model_type: 'yolov8' as string,
    model_size: 'n' as string,
    // Data split
    train_split: 0.7,
    val_split: 0.2,
    test_split: 0.1,
    // Training params
    epochs: 50,
    batch_size: 16,
    learning_rate: 0.001,
    image_size: 640,
    augmentation: true,
    pretrained: true,
    // Advanced
    optimizer: 'auto',
    patience: 50,
  });

  // Calculate stats
  const annotatedCount = images.filter((img) => (img.annotations_count || img.annotations?.length || 0) > 0).length;
  const totalAnnotations = images.reduce((sum, img) => sum + (img.annotations_count || img.annotations?.length || 0), 0);
  
  // Minimum requirements - reduced for testing
  const MIN_IMAGES = 10;
  const MIN_ANNOTATIONS = 20;

  return (
    <Layout isConnected={isConnected}>
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Обучение модели</h1>
            <p className="text-gray-600">Загрузите изображения, разметьте данные и обучите модель на своих данных</p>
          </div>
          
          {/* Dataset selector */}
          <div className="flex items-center gap-3">
            <label className="text-sm font-medium text-gray-700">Датасет:</label>
            <select
              value={currentDatasetId || ''}
              onChange={(e) => setCurrentDatasetId(e.target.value || null)}
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              disabled={datasetsLoading}
            >
              {datasets.length === 0 && (
                <option value="">Нет датасетов</option>
              )}
              {datasets.map((ds) => (
                <option key={ds.id} value={ds.id}>
                  {ds.name} ({ds.images_count} изобр.)
                </option>
              ))}
            </select>
            <button
              onClick={() => setShowDatasetModal(true)}
              className="btn-outline text-sm"
              title="Создать новый датасет"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Dataset Create Modal */}
      {showDatasetModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Новый датасет</h2>
              <button onClick={() => setShowDatasetModal(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Название</label>
                <input
                  type="text"
                  value={newDatasetName}
                  onChange={(e) => setNewDatasetName(e.target.value)}
                  placeholder="Например: Цех №1 - Январь 2026"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                />
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowDatasetModal(false)}
                  className="flex-1 btn-outline"
                >
                  Отмена
                </button>
                <button
                  onClick={() => createDatasetMutation.mutate({ name: newDatasetName })}
                  disabled={!newDatasetName.trim() || createDatasetMutation.isPending}
                  className="flex-1 btn-primary"
                >
                  {createDatasetMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    'Создать'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="flex gap-4" aria-label="Вкладки обучения">
          {[
            { id: 'upload', label: 'Загрузка', icon: Upload, count: images.length },
            { id: 'annotate', label: 'Разметка', icon: Tag, count: annotatedCount },
            { id: 'train', label: 'Обучение', icon: Cpu },
            { id: 'models', label: 'Модели', icon: Layers, count: models.length },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-3 border-b-2 text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              aria-current={activeTab === tab.id ? 'page' : undefined}
            >
              <tab.icon className="w-4 h-4" aria-hidden="true" />
              {tab.label}
              {tab.count !== undefined && (
                <span className="ml-1 px-2 py-0.5 rounded-full text-xs bg-gray-100">
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </nav>
      </div>

      {/* Upload Tab */}
      {activeTab === 'upload' && (
        <div className="space-y-6">
          {/* Warning if no dataset */}
          {!currentDatasetId && (
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-600" />
              <span className="text-yellow-800">Создайте или выберите датасет для загрузки изображений</span>
            </div>
          )}
          
          {/* Drop zone */}
          <div
            className={`border-2 border-dashed rounded-xl p-12 text-center transition-colors ${
              !currentDatasetId 
                ? 'border-gray-200 bg-gray-50 cursor-not-allowed' 
                : uploadMutation.isPending
                  ? 'border-primary-300 bg-primary-50'
                  : 'border-gray-300 hover:border-primary-400 hover:bg-gray-50'
            }`}
            onDrop={currentDatasetId ? handleDrop : undefined}
            onDragOver={(e) => e.preventDefault()}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
              aria-label="Выбрать изображения для загрузки"
              disabled={!currentDatasetId}
            />
            
            {uploadMutation.isPending ? (
              <div className="flex flex-col items-center">
                <Loader2 className="w-12 h-12 text-primary-500 animate-spin mb-4" />
                <p className="text-lg font-medium text-gray-900">Загрузка...</p>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <Upload className={`w-12 h-12 mb-4 ${currentDatasetId ? 'text-gray-400' : 'text-gray-300'}`} />
                <p className={`text-lg font-medium mb-2 ${currentDatasetId ? 'text-gray-900' : 'text-gray-400'}`}>
                  {currentDatasetId ? 'Перетащите изображения сюда' : 'Сначала выберите датасет'}
                </p>
                {currentDatasetId && (
                  <>
                    <p className="text-gray-500 mb-4">или</p>
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="btn-primary"
                      disabled={!currentDatasetId}
                    >
                      <FolderOpen className="w-4 h-4 mr-2" />
                      Выбрать файлы
                    </button>
                    <p className="text-xs text-gray-400 mt-4">
                      PNG, JPG, JPEG до 10MB каждый
                    </p>
                  </>
                )}
              </div>
            )}
            
            {/* Upload errors */}
            {uploadMutation.isError && (
              <div className="mt-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
                Ошибка загрузки: {(uploadMutation.error as Error)?.message}
              </div>
            )}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="card p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-100">
                  <ImageIcon className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{totalImages}</p>
                  <p className="text-sm text-gray-500">Изображений</p>
                </div>
              </div>
            </div>
            <div className="card p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-green-100">
                  <Tag className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{annotatedCount}</p>
                  <p className="text-sm text-gray-500">Размечено</p>
                </div>
              </div>
            </div>
            <div className="card p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-100">
                  <Square className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{totalAnnotations}</p>
                  <p className="text-sm text-gray-500">Аннотаций</p>
                </div>
              </div>
            </div>
            <div className="card p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-orange-100">
                  <AlertCircle className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{totalImages - annotatedCount}</p>
                  <p className="text-sm text-gray-500">Без разметки</p>
                </div>
              </div>
            </div>
          </div>

          {/* Images grid */}
          {totalImages > 0 && (
            <div className="card">
              <div className="p-4 border-b border-gray-200 flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-4">
                  <h2 className="font-semibold">Загруженные изображения</h2>
                  <span className="text-sm text-gray-500">
                    Показано {(currentPage - 1) * pageSize + 1} - {Math.min(currentPage * pageSize, totalImages)} из {totalImages}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  {/* Page size selector */}
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">На странице:</span>
                    <select 
                      value={pageSize}
                      onChange={(e) => {
                        setPageSize(Number(e.target.value));
                        setCurrentPage(1);
                      }}
                      className="px-2 py-1 border border-gray-300 rounded text-sm"
                    >
                      <option value={20}>20</option>
                      <option value={50}>50</option>
                      <option value={100}>100</option>
                    </select>
                  </div>
                  {selectedImages.size > 0 && (
                    <button 
                      className="btn-ghost text-danger-600 text-sm"
                      onClick={() => deleteImagesMutation.mutate(Array.from(selectedImages))}
                      disabled={deleteImagesMutation.isPending}
                    >
                      {deleteImagesMutation.isPending ? (
                        <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4 mr-1" />
                      )}
                      Удалить выбранные ({selectedImages.size})
                    </button>
                  )}
                </div>
              </div>
              
              {/* Images loading state */}
              {imagesLoading ? (
                <div className="p-8 flex items-center justify-center">
                  <Loader2 className="w-8 h-8 animate-spin text-primary-500" />
                  <span className="ml-2 text-gray-500">Загрузка изображений...</span>
                </div>
              ) : (
                <div className="p-4 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {images.map((image) => (
                    <div
                      key={image.id}
                      className={`relative aspect-square rounded-lg overflow-hidden border-2 cursor-pointer ${
                        selectedImages.has(image.id) ? 'border-primary-500' : 'border-transparent'
                      }`}
                      onClick={() => {
                        setSelectedImages((prev) => {
                          const next = new Set(prev);
                          if (next.has(image.id)) {
                            next.delete(image.id);
                          } else {
                            next.add(image.id);
                          }
                          return next;
                        });
                      }}
                    >
                      <img
                        src={image.url}
                        alt={image.filename}
                        className="w-full h-full object-cover"
                      />
                      {image.annotations.length > 0 && (
                        <div className="absolute top-2 right-2 px-2 py-0.5 bg-green-500 text-white text-xs rounded-full">
                          {image.annotations.length}
                        </div>
                      )}
                      {selectedImages.has(image.id) && (
                        <div className="absolute inset-0 bg-primary-500/20 flex items-center justify-center">
                          <CheckCircle className="w-8 h-8 text-primary-600" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
              
              {/* Pagination controls */}
              {totalPages > 1 && (
                <div className="p-4 border-t border-gray-200 flex items-center justify-center gap-2">
                  <button
                    onClick={() => setCurrentPage(1)}
                    disabled={currentPage === 1}
                    className="px-3 py-1 text-sm border rounded hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    ««
                  </button>
                  <button
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                    className="px-3 py-1 text-sm border rounded hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    «
                  </button>
                  
                  {/* Page numbers */}
                  {Array.from({ length: Math.min(7, totalPages) }, (_, i) => {
                    let pageNum: number;
                    if (totalPages <= 7) {
                      pageNum = i + 1;
                    } else if (currentPage <= 4) {
                      pageNum = i + 1;
                    } else if (currentPage >= totalPages - 3) {
                      pageNum = totalPages - 6 + i;
                    } else {
                      pageNum = currentPage - 3 + i;
                    }
                    return (
                      <button
                        key={pageNum}
                        onClick={() => setCurrentPage(pageNum)}
                        className={`px-3 py-1 text-sm border rounded ${
                          currentPage === pageNum 
                            ? 'bg-primary-500 text-white border-primary-500' 
                            : 'hover:bg-gray-50'
                        }`}
                      >
                        {pageNum}
                      </button>
                    );
                  })}
                  
                  <button
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    disabled={currentPage === totalPages}
                    className="px-3 py-1 text-sm border rounded hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    »
                  </button>
                  <button
                    onClick={() => setCurrentPage(totalPages)}
                    disabled={currentPage === totalPages}
                    className="px-3 py-1 text-sm border rounded hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    »»
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Empty state */}
          {images.length === 0 && !imagesLoading && (
            <div className="text-center py-12 text-gray-500">
              <ImageIcon className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium">Нет загруженных изображений</p>
              <p className="text-sm">Загрузите изображения для начала обучения</p>
            </div>
          )}
        </div>
      )}

      {/* Annotate Tab */}
      {activeTab === 'annotate' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Image list */}
          <div className="lg:col-span-1 card">
            <div className="p-3 border-b border-gray-200">
              <h3 className="font-medium text-sm">Изображения</h3>
            </div>
            <div className="max-h-[600px] overflow-y-auto">
              {images.length === 0 ? (
                <div className="p-4 text-center text-gray-500 text-sm">
                  Сначала загрузите изображения
                </div>
              ) : (
                images.map((image) => (
                  <button
                    key={image.id}
                    onClick={() => setCurrentImage(image)}
                    className={`w-full p-2 flex items-center gap-2 hover:bg-gray-50 border-l-2 ${
                      currentImage?.id === image.id
                        ? 'border-primary-500 bg-primary-50'
                        : 'border-transparent'
                    }`}
                  >
                    <img
                      src={image.url}
                      alt={image.filename}
                      className="w-12 h-12 rounded object-cover"
                    />
                    <div className="flex-1 text-left">
                      <p className="text-sm truncate">{image.filename}</p>
                      <p className="text-xs text-gray-500">
                        {image.annotations.length} аннотаций
                      </p>
                    </div>
                    {image.annotations.length > 0 ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-orange-400" />
                    )}
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Canvas area */}
          <div className="lg:col-span-2 card">
            <div className="p-3 border-b border-gray-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setTool('select')}
                  className={`p-2 rounded ${tool === 'select' ? 'bg-primary-100 text-primary-600' : 'hover:bg-gray-100'}`}
                  aria-label="Инструмент выбора"
                  aria-pressed={tool === 'select'}
                >
                  <MousePointer className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setTool('draw')}
                  className={`p-2 rounded ${tool === 'draw' ? 'bg-primary-100 text-primary-600' : 'hover:bg-gray-100'}`}
                  aria-label="Инструмент рисования"
                  aria-pressed={tool === 'draw'}
                >
                  <Square className="w-4 h-4" />
                </button>
                <div className="w-px h-6 bg-gray-200 mx-2" />
                <button
                  onClick={() => setZoom((z) => Math.min(3, z + 0.25))}
                  className="p-2 rounded hover:bg-gray-100"
                  aria-label="Увеличить"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                <span className="text-sm text-gray-500 w-12 text-center">{Math.round(zoom * 100)}%</span>
                <button
                  onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}
                  className="p-2 rounded hover:bg-gray-100"
                  aria-label="Уменьшить"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <div className="w-px h-6 bg-gray-200 mx-2" />
                {/* Auto-annotate buttons */}
                <button
                  onClick={() => currentImage && autoAnnotateMutation.mutate(currentImage.id)}
                  disabled={!currentImage || autoAnnotateMutation.isPending}
                  className="px-2 py-1 text-xs bg-purple-100 text-purple-700 rounded hover:bg-purple-200 disabled:opacity-50 flex items-center gap-1"
                  title="Авто-разметка текущего изображения"
                >
                  {autoAnnotateMutation.isPending ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  ) : (
                    <Cpu className="w-3 h-3" />
                  )}
                  Авто
                </button>
                <button
                  onClick={() => autoAnnotateAllMutation.mutate()}
                  disabled={!currentDatasetId || autoAnnotateAllMutation.isPending}
                  className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded hover:bg-green-200 disabled:opacity-50 flex items-center gap-1"
                  title="Авто-разметка всех неразмеченных изображений"
                >
                  {autoAnnotateAllMutation.isPending ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  ) : (
                    <Play className="w-3 h-3" />
                  )}
                  Авто все
                </button>
              </div>
              {currentImage && (
                <span className="text-sm text-gray-500">
                  {currentImage.width} × {currentImage.height}
                </span>
              )}
            </div>
            
            <div className="relative bg-gray-900 aspect-video overflow-auto">
              {currentImage ? (
                <div
                  ref={containerRef}
                  className="relative inline-block"
                  style={{ transform: `scale(${zoom})`, transformOrigin: 'top left' }}
                >
                  <img
                    ref={imageRef}
                    src={currentImage.url}
                    alt={currentImage.filename}
                    className="max-w-none"
                    draggable={false}
                    onLoad={handleImageLoad}
                    onError={handleImageError}
                  />
                  {imageLoadError && (
                    <div className="absolute inset-0 flex items-center justify-center bg-gray-800 text-red-400">
                      <div className="text-center">
                        <AlertCircle className="w-12 h-12 mx-auto mb-2" />
                        <p>{imageLoadError}</p>
                        <p className="text-xs text-gray-500 mt-2">{currentImage.url}</p>
                      </div>
                    </div>
                  )}
                  {imageDimensions && (
                    <canvas
                      ref={canvasRef}
                      width={imageDimensions.width}
                      height={imageDimensions.height}
                      className="absolute inset-0 cursor-crosshair"
                      onMouseDown={handleMouseDown}
                      onMouseMove={handleMouseMove}
                      onMouseUp={handleMouseUp}
                      onMouseLeave={handleMouseUp}
                    />
                  )}
                  {/* Render existing annotations */}
                  {currentImage.annotations.map((ann) => (
                    <div
                      key={ann.id}
                      className="absolute border-2 pointer-events-none"
                      style={{
                        left: `${ann.bbox[0] * 100}%`,
                        top: `${ann.bbox[1] * 100}%`,
                        width: `${(ann.bbox[2] - ann.bbox[0]) * 100}%`,
                        height: `${(ann.bbox[3] - ann.bbox[1]) * 100}%`,
                        borderColor: CLASS_COLORS[ann.class_name] || '#888',
                      }}
                    >
                      <span
                        className="absolute -top-5 left-0 px-1 text-xs text-white rounded"
                        style={{ backgroundColor: CLASS_COLORS[ann.class_name] || '#888' }}
                      >
                        {ann.class_name}
                      </span>
                    </div>
                  ))}
                  {/* Temp box while drawing */}
                  {tempBox && (
                    <div
                      className="absolute border-2 border-dashed pointer-events-none"
                      style={{
                        left: `${tempBox[0] * 100}%`,
                        top: `${tempBox[1] * 100}%`,
                        width: `${(tempBox[2] - tempBox[0]) * 100}%`,
                        height: `${(tempBox[3] - tempBox[1]) * 100}%`,
                        borderColor: CLASS_COLORS[selectedClass] || '#888',
                        backgroundColor: `${CLASS_COLORS[selectedClass]}20`,
                      }}
                    />
                  )}
                </div>
              ) : (
                <div className="absolute inset-0 flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <ImageIcon className="w-12 h-12 mx-auto mb-2 text-gray-600" />
                    <p>Выберите изображение для разметки</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Classes & annotations panel */}
          <div className="lg:col-span-1 space-y-4">
            {/* Class selector */}
            <div className="card">
              <div className="p-3 border-b border-gray-200">
                <h3 className="font-medium text-sm">Класс объекта</h3>
              </div>
              <div className="p-2">
                {CLASSES.map((cls) => (
                  <button
                    key={cls.id}
                    onClick={() => setSelectedClass(cls.id)}
                    className={`w-full p-2 flex items-center gap-2 rounded text-sm ${
                      selectedClass === cls.id
                        ? 'bg-gray-100 font-medium'
                        : 'hover:bg-gray-50'
                    }`}
                  >
                    <span
                      className="w-3 h-3 rounded"
                      style={{ backgroundColor: cls.color }}
                    />
                    {cls.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Current image annotations */}
            {currentImage && (
              <div className="card">
                <div className="p-3 border-b border-gray-200 flex items-center justify-between">
                  <h3 className="font-medium text-sm">Аннотации</h3>
                  <span className="text-xs text-gray-500">
                    {currentImage.annotations.length}
                  </span>
                </div>
                <div className="max-h-64 overflow-y-auto">
                  {currentImage.annotations.length === 0 ? (
                    <div className="p-4 text-center text-gray-500 text-sm">
                      Нарисуйте рамку вокруг объекта
                    </div>
                  ) : (
                    currentImage.annotations.map((ann) => (
                      <div
                        key={ann.id}
                        className="p-2 flex items-center justify-between hover:bg-gray-50 border-b border-gray-100"
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className="w-2 h-2 rounded"
                            style={{ backgroundColor: CLASS_COLORS[ann.class_name] }}
                          />
                          <span className="text-sm">{ann.class_name}</span>
                        </div>
                        <button
                          className="p-1 text-gray-400 hover:text-danger-500 rounded"
                          aria-label="Удалить аннотацию"
                          onClick={() => handleDeleteAnnotation(ann.id)}
                          disabled={deleteAnnotationMutation.isPending}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* Keyboard shortcuts */}
            <div className="card p-3">
              <h3 className="font-medium text-sm mb-2">Горячие клавиши</h3>
              <div className="text-xs text-gray-500 space-y-1">
                <div className="flex justify-between">
                  <span>Рисовать</span>
                  <kbd className="px-1 bg-gray-100 rounded">D</kbd>
                </div>
                <div className="flex justify-between">
                  <span>Выбрать</span>
                  <kbd className="px-1 bg-gray-100 rounded">V</kbd>
                </div>
                <div className="flex justify-between">
                  <span>Удалить</span>
                  <kbd className="px-1 bg-gray-100 rounded">Del</kbd>
                </div>
                <div className="flex justify-between">
                  <span>След. изображение</span>
                  <kbd className="px-1 bg-gray-100 rounded">→</kbd>
                </div>
              </div>
            </div>

            {/* Training Actions Panel */}
            <div className="card p-4 space-y-3">
              <h3 className="font-medium text-sm flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary-500" />
                Обучение модели
              </h3>
              
              {/* Stats */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-50 rounded p-2 text-center">
                  <div className="font-semibold text-lg text-primary-600">{totalImages}</div>
                  <div className="text-gray-500">Изображений</div>
                </div>
                <div className="bg-gray-50 rounded p-2 text-center">
                  <div className="font-semibold text-lg text-green-600">{annotatedCount}</div>
                  <div className="text-gray-500">Размечено</div>
                </div>
              </div>

              {/* Progress indicator */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span>Готовность</span>
                  <span>{Math.round((annotatedCount / Math.max(totalImages, 1)) * 100)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-primary-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (annotatedCount / Math.max(totalImages, 1)) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Quick Train Button */}
              <button
                onClick={() => {
                  if (annotatedCount >= MIN_IMAGES && totalAnnotations >= MIN_ANNOTATIONS) {
                    startTrainingMutation.mutate(trainingParams);
                  }
                }}
                disabled={
                  annotatedCount < MIN_IMAGES || 
                  totalAnnotations < MIN_ANNOTATIONS ||
                  startTrainingMutation.isPending ||
                  trainingJob?.status === 'running'
                }
                className="w-full btn-primary py-3 flex items-center justify-center gap-2"
                title={
                  annotatedCount < MIN_IMAGES 
                    ? `Нужно минимум ${MIN_IMAGES} размеченных изображений` 
                    : totalAnnotations < MIN_ANNOTATIONS 
                    ? `Нужно минимум ${MIN_ANNOTATIONS} аннотаций`
                    : 'Начать обучение с текущими настройками'
                }
              >
                {startTrainingMutation.isPending ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Запуск...
                  </>
                ) : trainingJob?.status === 'running' ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Обучение: {Math.round(trainingJob.progress || 0)}%
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5" />
                    Начать обучение
                  </>
                )}
              </button>

              {/* Minimum requirements warning */}
              {(annotatedCount < MIN_IMAGES || totalAnnotations < MIN_ANNOTATIONS) && (
                <div className="text-xs text-orange-600 bg-orange-50 rounded p-2">
                  <p className="font-medium">Требования для обучения:</p>
                  <ul className="mt-1 space-y-0.5">
                    <li className={annotatedCount >= MIN_IMAGES ? 'text-green-600' : ''}>
                      • Мин. {MIN_IMAGES} размеченных фото ({annotatedCount}/{MIN_IMAGES})
                    </li>
                    <li className={totalAnnotations >= MIN_ANNOTATIONS ? 'text-green-600' : ''}>
                      • Мин. {MIN_ANNOTATIONS} аннотаций ({totalAnnotations}/{MIN_ANNOTATIONS})
                    </li>
                  </ul>
                </div>
              )}

              {/* Go to Training tab */}
              <button
                onClick={() => setActiveTab('train')}
                className="w-full btn-outline text-sm py-2"
              >
                Настроить параметры обучения →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Train Tab */}
      {activeTab === 'train' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Model Selection & Training parameters */}
          <div className="lg:col-span-2 space-y-6">
            {/* Model Selection */}
            <div className="card">
              <div className="p-4 border-b border-gray-200">
                <h3 className="font-semibold">Выбор модели</h3>
                <p className="text-sm text-gray-500">Выберите архитектуру и размер модели YOLO</p>
              </div>
              <div className="p-4">
                <ModelSelector
                  selectedModel={trainingParams.model_type as ModelType}
                  selectedSize={trainingParams.model_size}
                  onModelChange={(model) => setTrainingParams(p => ({ ...p, model_type: model }))}
                  onSizeChange={(size) => setTrainingParams(p => ({ ...p, model_size: size }))}
                />
              </div>
            </div>

            {/* Data Split */}
            <div className="card">
              <div className="p-4 border-b border-gray-200">
                <h3 className="font-semibold">Разделение данных</h3>
              </div>
              <div className="p-4">
                <SplitSelector
                  trainSplit={trainingParams.train_split}
                  valSplit={trainingParams.val_split}
                  testSplit={trainingParams.test_split}
                  onTrainChange={(v) => setTrainingParams(p => ({ ...p, train_split: v }))}
                  onValChange={(v) => setTrainingParams(p => ({ ...p, val_split: v }))}
                  onTestChange={(v) => setTrainingParams(p => ({ ...p, test_split: v }))}
                />
              </div>
            </div>

            {/* Advanced Options (collapsible) */}
            <details className="card">
              <summary className="p-4 border-b border-gray-200 cursor-pointer">
                <span className="font-semibold">Дополнительные настройки</span>
              </summary>
              <div className="p-4">
                <AdvancedOptions
                  optimizer={trainingParams.optimizer}
                  patience={trainingParams.patience}
                  onOptimizerChange={(v) => setTrainingParams(p => ({ ...p, optimizer: v }))}
                  onPatienceChange={(v) => setTrainingParams(p => ({ ...p, patience: v }))}
                />
              </div>
            </details>
          </div>

          {/* Right sidebar - Parameters & Start */}
          <div className="lg:col-span-1 space-y-4">
            <div className="card">
              <div className="p-4 border-b border-gray-200">
                <h3 className="font-semibold">Параметры обучения</h3>
              </div>
              <div className="p-4 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Эпохи
                  </label>
                  <input
                    type="number"
                    value={trainingParams.epochs}
                    onChange={(e) => setTrainingParams((p) => ({ ...p, epochs: Number(e.target.value) }))}
                    className="input"
                    min={1}
                    max={500}
                  />
                  <p className="text-xs text-gray-500 mt-1">Рекомендуется: 50-100</p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Batch Size
                  </label>
                  <select
                    value={trainingParams.batch_size}
                    onChange={(e) => setTrainingParams((p) => ({ ...p, batch_size: Number(e.target.value) }))}
                    className="input"
                  >
                    <option value={4}>4 (мало VRAM)</option>
                    <option value={8}>8</option>
                    <option value={16}>16 (рекомендуется)</option>
                    <option value={32}>32</option>
                    <option value={64}>64</option>
                    <option value={128}>128 (много VRAM)</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Image Size
                  </label>
                  <select
                    value={trainingParams.image_size}
                    onChange={(e) => setTrainingParams((p) => ({ ...p, image_size: Number(e.target.value) }))}
                    className="input"
                  >
                    <option value={320}>320 (быстро)</option>
                    <option value={480}>480</option>
                    <option value={640}>640 (рекомендуется)</option>
                    <option value={800}>800</option>
                    <option value={1024}>1024 (точно)</option>
                    <option value={1280}>1280 (максимум)</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Learning Rate
                  </label>
                  <select
                    value={trainingParams.learning_rate}
                    onChange={(e) => setTrainingParams((p) => ({ ...p, learning_rate: Number(e.target.value) }))}
                    className="input"
                  >
                    <option value={0.01}>0.01 (высокий)</option>
                    <option value={0.001}>0.001 (стандартный)</option>
                    <option value={0.0001}>0.0001 (низкий)</option>
                  </select>
                </div>
                
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="augmentation"
                    checked={trainingParams.augmentation}
                    onChange={(e) => setTrainingParams((p) => ({ ...p, augmentation: e.target.checked }))}
                    className="rounded"
                  />
                  <label htmlFor="augmentation" className="text-sm text-gray-700">
                    Аугментация данных
                  </label>
                </div>
                
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="pretrained"
                    checked={trainingParams.pretrained}
                    onChange={(e) => setTrainingParams((p) => ({ ...p, pretrained: e.target.checked }))}
                    className="rounded"
                  />
                  <label htmlFor="pretrained" className="text-sm text-gray-700">
                    Использовать pretrained веса
                  </label>
                </div>
              </div>
              <div className="p-4 border-t border-gray-200">
                {trainingJob?.status === 'running' ? (
                  <button
                    onClick={() => cancelTrainingMutation.mutate(trainingJob.id)}
                    disabled={cancelTrainingMutation.isPending}
                    className="w-full btn-outline text-danger-600 border-danger-300 hover:bg-danger-50"
                  >
                    {cancelTrainingMutation.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <StopCircle className="w-4 h-4 mr-2" />
                    )}
                    Остановить обучение
                  </button>
                ) : (
                  <button
                    onClick={() => startTrainingMutation.mutate(trainingParams)}
                    disabled={annotatedCount < MIN_IMAGES || startTrainingMutation.isPending}
                    className="w-full btn-primary"
                  >
                    {startTrainingMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Запуск...
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 mr-2" />
                        Начать обучение
                      </>
                    )}
                  </button>
                )}
                {annotatedCount < MIN_IMAGES && (
                  <p className="text-xs text-orange-500 mt-2 text-center">
                    Нужно минимум {MIN_IMAGES} размеченных изображений (сейчас: {annotatedCount})
                  </p>
                )}
                {startTrainingMutation.isError && (
                  <p className="text-xs text-red-500 mt-2 text-center">
                    Ошибка: {(startTrainingMutation.error as Error)?.message}
                  </p>
                )}
              </div>
            </div>

            {/* Requirements */}
            <div className="card p-4">
              <h3 className="font-medium text-sm mb-3">Требования</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  {annotatedCount >= MIN_IMAGES ? (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-orange-400" />
                  )}
                  <span>Минимум {MIN_IMAGES} изображений ({annotatedCount}/{MIN_IMAGES})</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  {totalAnnotations >= MIN_ANNOTATIONS ? (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-orange-400" />
                  )}
                  <span>Минимум {MIN_ANNOTATIONS} аннотаций ({totalAnnotations}/{MIN_ANNOTATIONS})</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>GPU доступен</span>
                </div>
              </div>
            </div>
          </div>

          {/* Training progress */}
          <div className="lg:col-span-2 space-y-4">
            {trainingJob ? (
              <>
                {/* Progress card */}
                <div className="card p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold">Прогресс обучения</h3>
                    <span className={`badge ${
                      trainingJob.status === 'running' ? 'badge-primary' :
                      trainingJob.status === 'completed' ? 'badge-success' :
                      trainingJob.status === 'failed' ? 'badge-danger' : 'bg-gray-100'
                    }`}>
                      {trainingJob.status === 'running' && <Loader2 className="w-3 h-3 mr-1 animate-spin" />}
                      {trainingJob.status === 'running' ? 'Обучается' :
                       trainingJob.status === 'completed' ? 'Завершено' :
                       trainingJob.status === 'failed' ? 'Ошибка' : 'Ожидание'}
                    </span>
                  </div>
                  
                  {/* Progress bar */}
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Эпоха {trainingJob.epochs_completed}/{trainingJob.epochs_total}</span>
                      <span>{Math.round(trainingJob.progress)}%</span>
                    </div>
                    <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary-500 transition-all duration-300"
                        style={{ width: `${trainingJob.progress}%` }}
                      />
                    </div>
                  </div>
                  
                  {/* Metrics */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-500">Loss</p>
                      <p className="text-xl font-bold">{trainingJob.current_loss?.toFixed(4) || '-'}</p>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-500">Best mAP@50</p>
                      <p className="text-xl font-bold">{trainingJob.best_map50 ? (trainingJob.best_map50 * 100).toFixed(1) + '%' : '-'}</p>
                    </div>
                  </div>
                  
                  {trainingJob.status === 'failed' && trainingJob.error_message && (
                    <div className="mt-4 p-3 bg-danger-50 text-danger-700 rounded-lg text-sm">
                      {trainingJob.error_message}
                    </div>
                  )}
                </div>

                {/* Training chart placeholder */}
                <div className="card p-6">
                  <h3 className="font-semibold mb-4">График обучения</h3>
                  <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center text-gray-400">
                    <TrendingUp className="w-12 h-12" />
                    <span className="ml-2">Loss / mAP график</span>
                  </div>
                </div>
              </>
            ) : (
              <div className="card p-12 text-center">
                <Cpu className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Готово к обучению
                </h3>
                <p className="text-gray-500 mb-4">
                  Настройте параметры и нажмите "Начать обучение"
                </p>
                <div className="text-sm text-gray-400">
                  <p>Размечено: {annotatedCount} изображений</p>
                  <p>Всего аннотаций: {totalAnnotations}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Models Tab */}
      {activeTab === 'models' && (
        <div className="space-y-4">
          {models.map((model) => (
            <div
              key={model.id}
              className={`card p-4 ${model.is_active ? 'ring-2 ring-primary-500' : ''}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-gray-100 rounded-lg">
                    <Layers className="w-6 h-6 text-gray-600" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{model.name}</h3>
                      {model.is_active && (
                        <span className="badge-success text-xs">Активная</span>
                      )}
                    </div>
                    <p className="text-sm text-gray-500">
                      Создана: {new Date(model.created_at).toLocaleDateString('ru')}
                      {model.training_images_count && ` • ${model.training_images_count} изображений`}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">{(model.map50 * 100).toFixed(1)}%</p>
                    <p className="text-xs text-gray-500">mAP@50</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold">{(model.map50_95 * 100).toFixed(1)}%</p>
                    <p className="text-xs text-gray-500">mAP@50-95</p>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {!model.is_active && (
                      <button 
                        className="btn-primary text-sm"
                        onClick={() => activateModelMutation.mutate(model.id)}
                        disabled={activateModelMutation.isPending}
                      >
                        {activateModelMutation.isPending ? (
                          <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                        ) : (
                          <Check className="w-4 h-4 mr-1" />
                        )}
                        Активировать
                      </button>
                    )}
                    <a 
                      href={trainingApi.models.getDownloadUrl(model.id)}
                      className="btn-outline text-sm"
                      download
                    >
                      <Download className="w-4 h-4 mr-1" />
                      Скачать
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          {modelsLoading && (
            <div className="text-center py-12">
              <Loader2 className="w-8 h-8 mx-auto animate-spin text-primary-500" />
            </div>
          )}
          
          {!modelsLoading && models.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <Layers className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium">Нет обученных моделей</p>
              <p className="text-sm">Обучите модель на своих данных</p>
            </div>
          )}
        </div>
      )}
    </Layout>
  );
}
